### (a) Analyze the distribution of ETF's weekly returns ###
#----------------------------------------------------------#

#Caculate the weekly returns

log_R = as.data.frame(index[-1,])
for (i in colnames(index[,-9])){
  log_R[,i] = na.omit(diff(log(index[,i])))
}
View(log_R)

#Describe data

desc=describe(log_R)
View(desc)

#Graphs

par(mfrow=c(2,3))
for (i in colnames(log_R[,1:5])){
  print(i)
  hist(log_R[,i],breaks=25, main=i, xlab="R", probability = TRUE)
  curve(dnorm(x,mean(log_R[,i]),sd(log_R[,i])), lwd=1, add=TRUE)
}


#QQplot for Normal Distribution

par(mfrow=c(2,3))
for (i in colnames(log_R[,1:5])){
  qqnorm(log_R[,i], main = paste("Normal QQ plot",i))
  qqline(log_R[,i], col = 2)
}

#Test for normality and t-distribution

fittest = matrix(NA, nrow=5, ncol=4, dimnames=list(colnames(log_R[,1:5]), c("W stat","p_value of normality test","K-S stat","p_value of t-test")))
for (i in colnames(log_R[,1:5])){
  fittest[i,1]=shapiro.test(log_R[,i])$statistic
  fittest[i,2]=shapiro.test(log_R[,i])$p.value
  fittest[i,3]=ks.test.t(log_R[,i])$statistic
  fittest[i,4]=ks.test.t(log_R[,i])$p.value
}
fittest

#Export data

write.csv(log_R, file = "Log returns.csv")
write.csv(desc, file = "Descriptive statistics.csv")
write.csv(fittest, file = "Fitting distribution for ETFs.csv")


