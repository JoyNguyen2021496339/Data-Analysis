### (b) Analyze the correlations, and variance/covariance of the fund returns ###
#-------------------------------------------------------------------------------#

#Compare the relative risk among all funds

cov_mat = cov(log_R[,1:5])
cov_mat
cor_mat = cor(log_R[,1:5])
cor_mat

corrplot(cor_mat)
write.csv(cor_mat, file = "ETFs correlation matrix.csv")

#Compare the performance of funds with the S&P 500 index and Dow Jones Technology Index.
#Compute the weekly returns for the market index S&P 500 and Dow Jones Technology index

chart.Correlation(log_R[,1:7],method="pearson")