### (c)	Analyze the ETFS with their benchmarks (tracked index) ###
#---------------------------------------------------------------##

################
#Tracking error#
################

log_R = as.xts(log_R, order.by=as.Date(rownames(log_R)))
TE = matrix(NA, nrow=5, dimnames=list(colnames(log_R[,1:5]), c("Tracking Error")))
for (i in (1:5)){
  TE[i] = TrackingError(log_R[,i], log_R[,8])
}
TE
write.csv(TE, file = "Tracking error with benchmark IYW.csv")

#################
#Hypothesis test#
#################

#1)Test for equality of 2 variances

vartest = function(x){
  var.test(x, log_R$benchmark_IYW, ratio = 1, altenative = "two.sided")
}
vartest(log_R$VGT) #accept
vartest(log_R$PNQI) #reject
vartest(log_R$ROBO) #accept
vartest(log_R$XLK) #accept
vartest(log_R$IXN) #accept

#2)Test for equality of 2 means

meantest = function(x){
  if (vartest(x)$p.value >= 0.05){
    meantest = t.test(as.vector(x), as.vector(log_R$benchmark_IYW), altenative = "two.sided", var.equal = TRUE)
  } else{
    meantest = t.test(as.vector(x), as.vector(log_R$benchmark_IYW), altenative = "two.sided", var.equal = FALSE)
  }
}
print(meantest(log_R$VGT)) #accept
print(meantest(log_R$PNQI)) #accept
print(meantest(log_R$ROBO)) #accept
print(meantest(log_R$XLK)) #accept
print(meantest(log_R$IXN)) #accept

#Create a table to read the p-value outcomes

hypotest = matrix(NA, nrow=5, ncol=4, dimnames=list(colnames(log_R[,1:5]),c("F stat","p value of F-test","t stat","p value of t-test")))
for (i in colnames(log_R[,1:5])){
  hypotest[i,1]=vartest(log_R[,i])$statistic
  hypotest[i,2]=vartest(log_R[,i])$p.value
  hypotest[i,3]=meantest(log_R[,i])$statistic
  hypotest[i,4]=meantest(log_R[,i])$p.value
}
hypotest
write.csv(hypotest, file="Hypo test btw ETFs and benchmark.csv")
