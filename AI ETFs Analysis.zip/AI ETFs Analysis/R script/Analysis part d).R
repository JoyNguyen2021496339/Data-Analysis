### (d) Fama-French 1 ###
#-----------------------#

#Compute the excess returns of each ETF and the two indexes separately

R_ex = matrix(0,nrow=NROW(log_R),ncol=7)
for (i in 1:NCOL(R_ex)){
  R_ex[,i] = log_R[,i]-log_R[,9]
}
R_ex = data.frame(R_ex)
names(R_ex) = colnames(log_R[,1:7])
row.names(R_ex) = rownames(data.frame(log_R))
View(R_ex)

write.csv(R_ex, file = "Excess return for market model.csv")

##############
#Factor model#
##############

#SP500
SPfit1 = lm(VGT~SP500, data=R_ex)
summary(SPfit1)

SPfit2 = lm(PNQI~SP500, data=R_ex)
summary(SPfit2)

SPfit3 = lm(ROBO~SP500, data=R_ex)
summary(SPfit3)

SPfit4 = lm(XLK~SP500, data=R_ex)
summary(SPfit4)

SPfit5 = lm(IXN~SP500, data=R_ex)
summary(SPfit5)

#Dow Jones
DJfit1 = lm(VGT~DJUSTC, data=R_ex)
summary(DJfit1)

DJfit2 = lm(PNQI~DJUSTC, data=R_ex)
summary(DJfit2)

DJfit3 = lm(ROBO~DJUSTC, data=R_ex)
summary(DJfit3)

DJfit4 = lm(XLK~DJUSTC, data=R_ex)
summary(DJfit4)

DJfit5 = lm(IXN~DJUSTC, data=R_ex)
summary(DJfit5)


