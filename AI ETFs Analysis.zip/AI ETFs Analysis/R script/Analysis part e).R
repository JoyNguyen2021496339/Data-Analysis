### (e) Fama-French 3 ###
#-----------------------#

# pull the factor data from Dr French's website
temp = tempfile()
base = "http://mba.tuck.dartmouth.edu/pages/faculty/ken.french/ftp/"
factor = "F-F_Research_Data_Factors_weekly"
format =  "_TXT.zip"
full_url =  glue(base, factor,  format,  sep ="")

#Now we pass full_url to download.file().

download.file(full_url,temp,quiet = TRUE)

#Finally, we can read the txt file using read_table() after unzipping that data with the unz() function.

ff_3factors =  read.table(unz(temp,"F-F_Research_Data_Factors_weekly.txt"),
                          skip = 4, header=TRUE)

ff_3factors <- ff_3factors %>%
  mutate(date = rownames(ff_3factors)) %>%
  mutate(date = ymd(parse_date_time(date,"%y%m%d"))-days(2))

R_ex$date=as.Date(row.names(R_ex))
ff_all <- 
  R_ex %>% 
  left_join(ff_3factors, by = "date")

ff_all <-na.omit(ff_all)

ff_all <- ff_all %>%
  mutate(SMB=as.numeric(as.character(SMB)),
         HML=as.numeric(as.character(HML)),
         RF=as.numeric(as.character(RF)))

View(ff_all)

###########
#FF3 model#
###########

FF3VGT = lm(VGT~Mkt.RF+ SMB + HML, data=ff_all)
summary(FF3VGT)

FF3PNQI = lm(PNQI~Mkt.RF+ SMB + HML, data=ff_all)
summary(FF3PNQI)

FF3ROBO = lm(ROBO~Mkt.RF+ SMB + HML, data=ff_all)
summary(FF3ROBO)

FF3XLK = lm(XLK~Mkt.RF+ SMB + HML, data=ff_all)
summary(FF3XLK)

FF3IXN = lm(IXN~Mkt.RF+ SMB + HML, data=ff_all)
summary(FF3IXN)
