### (f)	Test for fitness of model in (d) and (e) ###
###----------------------------------------------###

###########
##(ANOVA)##
###########

#SP500
anova(SPfit1)
anova(SPfit2)
anova(SPfit3)
anova(SPfit4)
anova(SPfit5)

par(mfrow=c(2,3))
for (i in colnames(R_ex[,1:5])){
  plot(R_ex$SP500,R_ex[,i],pch = 10, cex = 0.5, col = "red", main=i)
  abline(lm(R_ex[,i]~R_ex$SP500))
}

#Dow Jones
anova(DJfit1)
anova(DJfit2)
anova(DJfit3)
anova(DJfit4)
anova(DJfit5)

par(mfrow=c(2,3))
for (i in colnames(R_ex[,1:5])){
  plot(R_ex$DJ,R_ex[,i],pch = 10, cex = 0.5, col = "red", main=i)
  abline(lm(R_ex[,i]~R_ex$DJ))
}

#FF3
anova(FF3VGT)
anova(FF3PNQI)
anova(FF3ROBO)
anova(FF3XLK)
anova(FF3IXN)

#############
##R-squared##
#############

R_SP = c(summary(SPfit1)$r.squared,
         summary(SPfit2)$r.squared,
         summary(SPfit3)$r.squared,
         summary(SPfit4)$r.squared,
         summary(SPfit5)$r.squared)

R_DJ = c(summary(DJfit1)$r.squared,
         summary(DJfit2)$r.squared,
         summary(DJfit3)$r.squared,
         summary(DJfit4)$r.squared,
         summary(DJfit5)$r.squared)

R_FF3 = c(summary(FF3VGT)$r.squared,
          summary(FF3PNQI)$r.squared,
          summary(FF3ROBO)$r.squared,
          summary(FF3XLK)$r.squared,
          summary(FF3IXN)$r.squared)

R_sqr = data.frame(R_SP, R_DJ, R_FF3)
names(R_sqr) = c("~SP500", "~DJUSTC", "~FF3")
row.names(R_sqr) = tickers[1:5]

R_sqr
write.csv(R_sqr, file = "R-squared analysis.csv")


#####################
## Model Diagnostic##
#####################

layout(matrix(c(1,2,3,4),2,2))

#SP500
plot(SPfit1, main="VGT~SP500")
plot(SPfit2, main="PNQI~SP500")
plot(SPfit3, main="ROBO~SP500")
plot(SPfit4, main="XLK~SP500")
plot(SPfit5, main="IXN~SP500")

#DJUSTC
plot(DJfit1, main="VGT~DJUSTC")
plot(DJfit2, main="PNQI~DJUSTC")
plot(DJfit3, main="ROBO~DJUSTC")
plot(DJfit4, main="XLK~DJUSTC")
plot(DJfit5, main="IXN~DJUSTC")

#FF3
plot(FF3VGT, main="VGT~FF3")
plot(FF3PNQI, main="PNQI~FF3")
plot(FF3ROBO, main="ROBO~FF3")
plot(FF3XLK, main="XLK~FF3")
plot(FF3IXN, main="IXN~FF3")

########################
##Assumptions conflict##
########################

# Test for heteroskadasticity (normal distribution of error terms)
#Ho: Homo (no conflict)

#SP500
bptest(SPfit1) #accept 
bptest(SPfit2) #accept
bptest(SPfit3) #accept
bptest(SPfit4) #accept
bptest(SPfit5) #accept

#Dow Jones
bptest(DJfit1) #reject
bptest(DJfit2) #reject
bptest(DJfit3) #reject
bptest(DJfit4) #reject
bptest(DJfit5) #reject

#FF3
bptest(FF3VGT) #accept 
bptest(FF3PNQI) #accept 
bptest(FF3ROBO) #accept 
bptest(FF3XLK) #accept 
bptest(FF3IXN) #accept 

#Create a table to read the p-value outcomes
bpSP = c(bptest(SPfit1)$p.value,
         bptest(SPfit2)$p.value,
         bptest(SPfit3)$p.value,
         bptest(SPfit4)$p.value,
         bptest(SPfit5)$p.value)

bpDJ = c(bptest(DJfit1)$p.value,
         bptest(DJfit2)$p.value,
         bptest(DJfit3)$p.value,
         bptest(DJfit4)$p.value,
         bptest(DJfit5)$p.value)

bpFF3 = c(bptest(FF3VGT)$p.value, 
          bptest(FF3PNQI)$p.value, 
          bptest(FF3ROBO)$p.value,
          bptest(FF3XLK)$p.value,
          bptest(FF3IXN)$p.value)

heter_test = data.frame(bpSP, bpDJ, bpFF3)
names(heter_test) = c("~SP500", "~DJUSTC", "~FF3")
row.names(heter_test) = tickers[1:5]

heter_test
write.csv(heter_test, file = "P-value of Heteroskedasticity test.csv")


# Test for Autocorrelated Errors
#H0: cor(e(t), e(t-1))=0 (no auto)

#SP500
durbinWatsonTest(SPfit1, simulate = FALSE) #accept 
durbinWatsonTest(SPfit2, simulate = FALSE) #accept
durbinWatsonTest(SPfit3, simulate = FALSE) #accept
durbinWatsonTest(SPfit4, simulate = FALSE) #accept
durbinWatsonTest(SPfit5, simulate = FALSE) #accept

#Dow Jones
durbinWatsonTest(DJfit1, simulate = FALSE) #reject
durbinWatsonTest(DJfit2, simulate = FALSE) #reject
durbinWatsonTest(DJfit3, simulate = FALSE) #accept
durbinWatsonTest(DJfit4, simulate = FALSE) #reject
durbinWatsonTest(DJfit5, simulate = FALSE) #reject

#FF3
durbinWatsonTest(FF3VGT, simulate = FALSE) #accept 
durbinWatsonTest(FF3PNQI, simulate = FALSE) #accept 
durbinWatsonTest(FF3ROBO, simulate = FALSE) #accept 
durbinWatsonTest(FF3XLK, simulate = FALSE) #accept 
durbinWatsonTest(FF3IXN, simulate = FALSE) #accept 

#Create a table to read the D-W statistics outcomes (N=300)
DW_SP = c(durbinWatsonTest(SPfit1, simulate = FALSE)$p, #k=1 ->  dl=1.804 ; du=1.817
          durbinWatsonTest(SPfit2, simulate = FALSE)$p,
          durbinWatsonTest(SPfit3, simulate = FALSE)$p,
          durbinWatsonTest(SPfit4, simulate = FALSE)$p,
          durbinWatsonTest(SPfit5, simulate = FALSE)$p)

DW_DJ = c(durbinWatsonTest(DJfit1, simulate = FALSE)$p, #k=1 ->  dl=1.804 ; du=1.817
          durbinWatsonTest(DJfit2, simulate = FALSE)$p,
          durbinWatsonTest(DJfit3, simulate = FALSE)$p,
          durbinWatsonTest(DJfit4, simulate = FALSE)$p,
          durbinWatsonTest(DJfit5, simulate = FALSE)$p)

DW_FF3 = c(durbinWatsonTest(FF3VGT, simulate = FALSE)$p, #k=3 ->  dl=1.791 ; du=1.831
           durbinWatsonTest(FF3PNQI, simulate = FALSE)$p, 
           durbinWatsonTest(FF3ROBO, simulate = FALSE)$p,
           durbinWatsonTest(FF3XLK, simulate = FALSE)$p,
           durbinWatsonTest(FF3IXN, simulate = FALSE)$p)

auto_test = data.frame(DW_SP, DW_DJ, DW_FF3)
names(auto_test) = c("~SP500", "~DJUSTC", "~FF3")
row.names(auto_test) = tickers[1:5]

auto_test
write.csv(auto_test, file = "D-W p-values for Auto-correlation test.csv")

# Evaluate Collinearity: variance inflation factors for multi regression 
# FF3 only
vif(FF3VGT) #same results for all 5 ETFs

################
##Fix DJ model##
################
install.packages("gmm") #Hansen's method
library(gmm)

#DJUSTC model
coeftest(DJfit3, vcov = vcovHC(DJfit3, "HC1")) #ROBO only exposes to heteroskedasticity
                                                
summary(gmm(R_ex$VGT~R_ex$DJUSTC, x=R_ex$DJUSTC))
summary(gmm(R_ex$PNQI~R_ex$DJUSTC, x=R_ex$DJUSTC))
summary(gmm(R_ex$XLK~R_ex$DJUSTC, x=R_ex$DJUSTC))
summary(gmm(R_ex$IXN~R_ex$DJUSTC, x=R_ex$DJUSTC))

#FF3 model
x = cbind(ff_all$Mkt.RF, ff_all$SMB, ff_all$HML)

summary(gmm(ff_all$VGT~ff_all$Mkt.RF+ff_all$SMB+ff_all$HML, x=x))
summary(gmm(ff_all$PNQI~ff_all$Mkt.RF+ff_all$SMB+ff_all$HML, x=x))
summary(gmm(ff_all$ROBO~ff_all$Mkt.RF+ff_all$SMB+ff_all$HML, x=x))
summary(gmm(ff_all$XLK~ff_all$Mkt.RF+ff_all$SMB+ff_all$HML, x=x))
summary(gmm(ff_all$IXN~ff_all$Mkt.RF+ff_all$SMB+ff_all$HML, x=x))





