install.packages("pdfetch")
install.packages("moments")
install.packages("MASS")
install.packages("car")
install.packages("lmtest")
install.packages("PerformanceAnalytics")
install.packages("psych")
install.packages("corrplot")
install.packages("ggpubr")
install.packages("nortest")
install.packages("LambertW")
install.packages("readxl")
library(readxl)
library(LambertW)
library(nortest)
library(ggplot2)
library(magrittr)
library(MASS)
library(car)
library(lmtest)
library(PerformanceAnalytics)
library(psych)
library(corrplot)
library(pdfetch)
library(moments)
library(tidyverse)
library(glue)
library(dplyr)
library(lubridate)

getwd()

### DATA FOR 5 ETFS, SP500&DJ, tracking index IYW, and risk-free rate ^IRX
tickers = c("VGT","PNQI","ROBO","XLK","IXN","^GSPC","IYW","^IRX")
price = pdfetch_YAHOO(tickers,fields="adjclose",from="2014-01-01", to="2019-10-01", interval= "1wk")
price = as.data.frame(price)
price$date = as.Date(row.names(price))

dailyDJ = read_excel("Dow Jones Technology Data.xls")
dailyDJ = as.data.frame(dailyDJ)
dailyDJ$date = as.Date(dailyDJ$`Effective date`)

combine <- 
  price%>% 
  left_join(dailyDJ, by = "date")

combine<-na.omit(combine)

index = data.frame(combine[1:5], SP500=combine$`^GSPC`, 
                   DJUSTC=combine$`Dow Jones U.S. Technology Index`, 
                   benchmark_IYW=combine$IYW, rf=(combine$`^IRX`/52)/100)
row.names(index) = combine$`Effective date`

for(i in (1:9)){
  index[,i]=as.numeric(index[,i])
}
View(index)
