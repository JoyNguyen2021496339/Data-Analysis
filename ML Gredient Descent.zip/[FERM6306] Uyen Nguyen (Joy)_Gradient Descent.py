# -*- coding: utf-8 -*-
"""
Created on Thu May  7 12:30:02 2020

@author: thuuy
"""

import numpy as np
import sympy as sym
import matplotlib.pyplot as plt
np.set_printoptions(precision=5)

#1.SPHERE: x1**2 + x2**2
#2.ROSENBROCK: 100*(x2-x1**2)**2 + (1-x1)**2
#3.BEALE: (1.5-x1+x1*x2)**2 + (2.25-x1+x1*x2**2)**2 + (2.625-x1+x1*x2**3)**2

#Define function (Example of Figure 7.3)
def func(x1,x2):
    return x1**2 + x1*x2 + 10*x2**2 - 5*x1 + 3*x2

#Gradient Descent
x1, x2 = sym.symbols('x1 x2')
pd1 = sym.diff(func(x1,x2),x1)
pd2 = sym.diff(func(x1,x2),x2)
dfdx1 = sym.lambdify((x1, x2), pd1)
dfdx2 = sym.lambdify((x1, x2), pd2)

def grad(x1,x2):
    return np.array([dfdx1(x1,x2), dfdx2(x1,x2)])

def grad_des(vec_xi, stepi):
    X1 = [vec_x0[0]]
    X2 = [vec_x0[1]]
    learning_rates = []
    vec_xi_plus1 = np.subtract(vec_xi, stepi*grad(vec_xi[0],vec_xi[1]))
    learning_rates = np.append(learning_rates, stepi)
    if func(vec_xi_plus1[0], vec_xi_plus1[1]) < func(vec_xi[0],vec_xi[1]):
        X1 = np.append(X1, vec_xi_plus1[0])
        X2 = np.append(X2, vec_xi_plus1[1])
        while func(vec_xi_plus1[0], vec_xi_plus1[1]) < func(vec_xi[0],vec_xi[1]):
            vec_xi = vec_xi_plus1
            vec_xi_plus1 = np.subtract(vec_xi, stepi*grad(vec_xi[0],vec_xi[1]))
            X1 = np.append(X1, vec_xi_plus1[0])
            X2 = np.append(X2, vec_xi_plus1[1])
        return (vec_xi_plus1, learning_rates, func(vec_xi_plus1[0], vec_xi_plus1[1]), X1, X2)
    else:
        while func(vec_xi_plus1[0], vec_xi_plus1[1]) >= func(vec_xi[0],vec_xi[1]):
            stepi = 0.5 * stepi
            vec_xi_plus1 = np.subtract(vec_xi, stepi*grad(vec_xi[0],vec_xi[1]))
            learning_rates = np.append(learning_rates, stepi)
            if func(vec_xi_plus1[0], vec_xi_plus1[1]) < func(vec_xi[0],vec_xi[1]):
                X1 = np.append(X1, vec_xi_plus1[0])
                X2 = np.append(X2, vec_xi_plus1[1])
                while func(vec_xi_plus1[0], vec_xi_plus1[1]) < func(vec_xi[0],vec_xi[1]):
                    vec_xi = vec_xi_plus1
                    vec_xi_plus1 = np.subtract(vec_xi, stepi*grad(vec_xi[0],vec_xi[1]))
                    X1 = np.append(X1, vec_xi_plus1[0])
                    X2 = np.append(X2, vec_xi_plus1[1])
                return (vec_xi_plus1, learning_rates, func(vec_xi_plus1[0], vec_xi_plus1[1]), X1, X2)
         
#Mapping
def figure(x,y,f,X,Y):
    fig = plt.contour(x, y, f, colors='white', linestyles='solid', linewidths=1)
    plt.clabel(fig, inline=1, fontsize=10, fmt='%1.1f')
    plt.plot(X, Y, "y-")
    plt.plot(X[0], Y[0], "y.")
    plt.plot(X[-1], Y[-1], "r*")
    fig = plt.contourf(x, y, f, )
    plt.colorbar(fig)
    plt.xlabel('x1')
    plt.ylabel('x2')
    plt.title('Gradient Descent Figure')
    return plt.show()

#Set domain
x1_dm = np.arange(-4, 5)
x2_dm = np.arange(-2, 3)
x1, x2 = np.meshgrid(x1_dm, x2_dm)
f = func(x1,x2)

#Playing arount with the Output
vec_x0 = np.array([-3,-1])
step0 = 0.085
output=grad_des(vec_x0, step0)
X1 = output[3]
X2 = output[4]

figure(x1, x2, f, X1, X2)
print('Starting point: ', vec_x0)
print('Starting rate: ', step0)
print('Changing rate: ', output[1])
print('Min (x1, x2): ', output[0])
print('Min f: ', output[2])
