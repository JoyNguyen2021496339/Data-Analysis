#Excess Return
excess = all
for (i in colnames(excess[,1:50])){
  excess[,i] = excess[,i] - excess$RF
}
View(excess)

#Market Model
MM = matrix(NA, nrow = 50, ncol = 5, 
                 dimnames=list(paste(colnames(excess[,1:50])), 
                               c("alpha", "alpha's SE", "alpha's t-value","Mkt","Mkt's p-value")))
for (i in colnames(excess[,1:50])){
  MM[i,1] = summary(lm(paste(i, "~Mkt.RF"), data=excess))$coef["(Intercept)","Estimate"]
  MM[i,2] = summary(lm(paste(i, "~Mkt.RF"), data=excess))$coef["(Intercept)","Std. Error"]
  MM[i,3] = summary(lm(paste(i, "~Mkt.RF"), data=excess))$coef["(Intercept)","t value"]
  MM[i,4] = summary(lm(paste(i, "~Mkt.RF"), data=excess))$coef["Mkt.RF","Estimate"]
  MM[i,5] = summary(lm(paste(i, "~Mkt.RF"), data=excess))$coef["Mkt.RF","Pr(>|t|)"]
}

MM = as.data.frame(MM)
View(describe(MM))
hist(MM$`alpha's t-value`,col="light grey",
     main="Frequency Distribution of t-ratios for alpha in MM", 
     xlab="t-ratio", labels=TRUE)

write.csv(MM, file ="Market Model.csv")
write.csv(describe(MM), file ="MM alpha distribution.csv")

#Fama-French 5
FM5 = matrix(NA, nrow = 50, ncol = 13, 
                  dimnames=list(paste(colnames(excess[,1:50])), 
                                c("alpha", "alpha's SE", "alpha's t-value","Mkt","Mkt's p-value",
                                  "SMB","SMB's p-value","HML","HML's p-value","RMW","RMW's p-value",
                                  "CMA","CMA's p-value")))
for (i in colnames(excess[,1:50])){
  FM5[i,1] = summary(lm(paste(i, "~Mkt.RF+SMB+HML+RMW+CMA"), data=excess))$coef["(Intercept)","Estimate"]
  FM5[i,2] = summary(lm(paste(i, "~Mkt.RF+SMB+HML+RMW+CMA"), data=excess))$coef["(Intercept)","Std. Error"]
  FM5[i,3] = summary(lm(paste(i, "~Mkt.RF+SMB+HML+RMW+CMA"), data=excess))$coef["(Intercept)","t value"]
  FM5[i,4] = summary(lm(paste(i, "~Mkt.RF+SMB+HML+RMW+CMA"), data=excess))$coef["Mkt.RF","Estimate"]
  FM5[i,5] = summary(lm(paste(i, "~Mkt.RF+SMB+HML+RMW+CMA"), data=excess))$coef["Mkt.RF","Pr(>|t|)"]
  FM5[i,6] = summary(lm(paste(i, "~Mkt.RF+SMB+HML+RMW+CMA"), data=excess))$coef["SMB","Estimate"]
  FM5[i,7] = summary(lm(paste(i, "~Mkt.RF+SMB+HML+RMW+CMA"), data=excess))$coef["SMB","Pr(>|t|)"]
  FM5[i,8] = summary(lm(paste(i, "~Mkt.RF+SMB+HML+RMW+CMA"), data=excess))$coef["HML","Estimate"]
  FM5[i,9] = summary(lm(paste(i, "~Mkt.RF+SMB+HML+RMW+CMA"), data=excess))$coef["HML","Pr(>|t|)"]
  FM5[i,10] = summary(lm(paste(i, "~Mkt.RF+SMB+HML+RMW+CMA"), data=excess))$coef["RMW","Estimate"]
  FM5[i,11] = summary(lm(paste(i, "~Mkt.RF+SMB+HML+RMW+CMA"), data=excess))$coef["RMW","Pr(>|t|)"]
  FM5[i,12] = summary(lm(paste(i, "~Mkt.RF+SMB+HML+RMW+CMA"), data=excess))$coef["CMA","Estimate"]
  FM5[i,13] = summary(lm(paste(i, "~Mkt.RF+SMB+HML+RMW+CMA"), data=excess))$coef["CMA","Pr(>|t|)"]
}

FM5 = as.data.frame(FM5)
View(describe(FM5))
hist(FM5$`alpha's t-value`, col = "light grey",
     main="Frequency Distribution of t-ratios for alpha in FM5", xlab="t-ratio", labels=TRUE)

write.csv(FM5, file ="Fama5 Model.csv")
write.csv(describe(FM5), file ="Fama5 alpha distribution.csv")
