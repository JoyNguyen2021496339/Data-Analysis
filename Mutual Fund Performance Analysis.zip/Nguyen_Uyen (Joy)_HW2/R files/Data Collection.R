install.packages("pdfetch")
install.packages("moments")
install.packages("MASS")
install.packages("car")
install.packages("lmtest")
install.packages("PerformanceAnalytics")
install.packages("psych")
install.packages("corrplot")
install.packages("ggpubr")
install.packages("nortest")
install.packages("LambertW")
library(LambertW)
library(nortest)
library(ggplot2)
library(magrittr)
library(MASS)
library(car)
library(lmtest)
library(PerformanceAnalytics)
library(psych)
library(corrplot)
library(pdfetch)
library(moments)
library(tidyverse)
library(glue)
library(dplyr)
library(lubridate)

### GET DATA FOR 50 MUTUAL FUNDS 
tickers = c("AMRMX","IYCEX","FRINX","CHRRX","ILUAX","LLPFX","FEAIX","PRBLX","FIDAX","JEFSX",
            "AGOCX","TEDSX","BEDCX","VTSPX","NYVRX","SAGYX","DNVYX","ITHAX","ABEMX","TWCGX",
            "ORDAX","BSMNX","TCPIX","FISRX","AZUCX","SEPIX","INTLX","TVVFX","MADVX","VEXAX",
            "VIIIX","RGABX","CEUFX","FCNTX","RIRBX","FXAIX","FCNKX","ISOLX","DODFX","RESIX",
            "RGAGX","VWELX","CIREX","CAIFX","VPMCX","DODIX","FESGX","DCDEX","GARBX","STDAX")

price = pdfetch_YAHOO(tickers,fields="adjclose",from="2013-12-01", to="2019-12-31", interval= "1mo")
log_R = as.data.frame(price[-1,])
for (i in colnames(price)){
  log_R[,i] = na.omit(diff(log(price[,i])))
}

# pull the factor data from Dr French's website
temp = tempfile()
base = "http://mba.tuck.dartmouth.edu/pages/faculty/ken.french/ftp/"
factor = "F-F_Research_Data_5_Factors_2x3"
format =  "_TXT.zip"
full_url =  glue(base, factor,  format,  sep ="")

#Now we pass full_url to download.file().

download.file(full_url,temp,quiet = TRUE)

#Finally, we can read the txt file using read_table() after unzipping that data with the unz() function.

ff_5factors =  read.table(unz(temp,"F-F_Research_Data_5_Factors_2x3.txt"), 
                          skip = 3, header = TRUE, nrows = 678)

name = rep("NA", nrow(ff_5factors))
for (i in (1:length(name))){
   name[i] = paste(rownames(ff_5factors[i,]), "01", sep = "")
}
row.names(ff_5factors) = name

ff_5factors = ff_5factors %>%
  mutate(date = rownames(ff_5factors)) %>%
  mutate(date = ymd(parse_date_time(date,"%y%m%d")))

log_R$date=as.Date(row.names(log_R))

all <- 
  log_R %>% 
  left_join(ff_5factors, by = "date")

all <-na.omit(all)

for(i in colnames(all)){
  all[,i]=as.numeric(all[,i])
}
row.names(all)=as.Date(all$date)
all$date = NULL
all[,51:56] = all[,51:56] / 100

View(all)



