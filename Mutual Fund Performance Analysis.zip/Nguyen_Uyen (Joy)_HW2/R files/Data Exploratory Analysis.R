#Descriptive Statistics
desc=describe(all[,1:50])
View(desc)

write.csv(desc, file = "Descriptive statistics.csv")


#Distribution curve
par(mfrow=c(2,5))
for (i in colnames(all[,1:50])){
  hist(all[,i],breaks=10, main=i, xlab="log R", probability = TRUE)
  curve(dnorm(x,mean(all[,i]),sd(all[,i])), lwd=1, add=TRUE)
}
#Boxplot
boxplot(all[,1:10], main="Score = 1")   #Rank=1
boxplot(all[,11:20], main="Score = 2")  #Rank=2
boxplot(all[,21:30], main="Score = 3")  #Rank=3
boxplot(all[,31:40], main="Score = 4")  #Rank=4
boxplot(all[,41:50], main="Score = 5")  #Rank=5

#Correlation
Mkt = all$Mkt.RF + all$RF
cor_mat = cor(cbind(all[,1:50],Mkt))

write.csv(cor_mat, file ="Correlation Statistics.csv")

corrplot(cor_mat, tl.cex = 0.5, tl.col = "black",
         cl.cex = 0.5, cl.ratio = 0.1)


